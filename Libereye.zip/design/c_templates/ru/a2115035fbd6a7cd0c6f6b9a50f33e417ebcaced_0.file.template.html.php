<?php /* Smarty version 3.1.27, created on 2015-12-22 11:11:23
         compiled from "d:\Server\domains\libereye2\Libereye\design\templates\ru\admin\template.html" */ ?>
<?php
/*%%SmartyHeaderCode:5756567905ab362919_51761097%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a2115035fbd6a7cd0c6f6b9a50f33e417ebcaced' => 
    array (
      0 => 'd:\\Server\\domains\\libereye2\\Libereye\\design\\templates\\ru\\admin\\template.html',
      1 => 1450771876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5756567905ab362919_51761097',
  'variables' => 
  array (
    'sTitle' => 0,
    'sBaseUrl' => 0,
    'bLoadEditor' => 0,
    'jsValidatorMess' => 0,
    'sJsMessages' => 0,
    'aMenu' => 0,
    'aMenuItem' => 0,
    'sTplName' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_567905abbafef6_80722488',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_567905abbafef6_80722488')) {
function content_567905abbafef6_80722488 ($_smarty_tpl) {
if (!is_callable('smarty_function_url')) require_once 'D:\\Server\\domains\\libereye2\\Libereye\\include\\classes\\utils\\smarty\\plugins\\function.url.php';

$_smarty_tpl->properties['nocache_hash'] = '5756567905ab362919_51761097';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
<title><?php echo $_smarty_tpl->tpl_vars['sTitle']->value;?>
 — RBengine</title>
<meta name="robots" content="NOINDEX,NOFOLLOW" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<base  href="<?php echo $_smarty_tpl->tpl_vars['sBaseUrl']->value;?>
" id="base" />
<link rel="stylesheet" type="text/css" href="design/css/admin.css">
<?php echo '<script'; ?>
 language='JavaScript' src='design/js/validator.js'><?php echo '</script'; ?>
>
<!--<link type="text/css" href="design/js/jquery/custom-theme/jquery.ui.all.css" rel="stylesheet" />-->
<?php echo '<script'; ?>
 language='JavaScript' src='design/js/jquery/jquery-1.11.0.min.js'><?php echo '</script'; ?>
>

<link rel="stylesheet" href="design/js/webix/codebase/webix.css" type="text/css" charset="utf-8">
<?php echo '<script'; ?>
 src="design/js/webix/codebase/webix.js" type="text/javascript" charset="utf-8"><?php echo '</script'; ?>
>

<?php if ($_smarty_tpl->tpl_vars['bLoadEditor']->value) {?>

<!-- tinyMCE -->
<?php echo '<script'; ?>
 language="javascript" type="text/javascript" src="design/js/tiny_mce/tiny_mce.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 language="javascript" type="text/javascript">
tinyMCE.init({
		// General options
		mode : "exact",
		elements : "text,text1,text2,text3,text4,text5,full_news,full_news1,full_news2,full_news3,full_news4",
		editor_selector : "mceAdvanced",
		theme : "advanced",
		plugins : "imagemanager,filemanager,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,youtubeIframe,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",


		// Theme options
		// Theme options
		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,insertimage,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,youtubeIframe,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,pagebreak,restoredraft",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,


		// Example content CSS (should be your site CSS)
		content_css:"/design/css/style.css,/design/css/table.css,/design/css/style-feed.css,/design/css/admin_editor.css",
		
		language: "ru",
        cleanup : false,
        verify_html : false,
        cleanup_on_startup : false,
        forced_root_block : false,
        force_p_newlines : false,
        remove_linebreaks : false,
        force_br_newlines : true,
        remove_trailing_nbsp : false

	});

	
<?php echo '</script'; ?>
>
<!-- /tinyMCE -->

<?php }?>    
<?php echo $_smarty_tpl->tpl_vars['jsValidatorMess']->value;?>

<?php echo $_smarty_tpl->tpl_vars['sJsMessages']->value;?>

</head>

<body id="index">
<div id="wrap">

<div id="header">
	<div id="header_top"><img src="/design/pic/admin/header_logo.gif" id="header_logo" alt="VMengine" /><sup class="k_logo">K</sup><br />
			<img src="/design/pic/admin/header_text.gif" id="header_text" alt="система управления контентом сайта" /> 
			<a class="website" href="http://libereye.com/" target="_blank">libereye.com</a><br />
			<a class="exit dark" href="/admin/logout.php">Выход</a></div>
		<hr class="hidden" />
		<div class="top_menu">
			<?php
$_from = $_smarty_tpl->tpl_vars['aMenu']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['aMenuItem'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['aMenuItem']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['aMenuItem']->value) {
$_smarty_tpl->tpl_vars['aMenuItem']->_loop = true;
$foreach_aMenuItem_Sav = $_smarty_tpl->tpl_vars['aMenuItem'];
?>
	        <?php if ($_smarty_tpl->tpl_vars['aMenuItem']->value['is_active']) {?>
	        	<span class="item"><span class="current"><?php echo $_smarty_tpl->tpl_vars['aMenuItem']->value['title'];?>
</span>	</span>
	        <?php } else { ?>
	       	 	<span class="item"><a href="<?php echo smarty_function_url(array('link'=>$_smarty_tpl->tpl_vars['aMenuItem']->value['url']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['aMenuItem']->value['title'];?>
</a></span>
	        <?php }?>
	        <?php
$_smarty_tpl->tpl_vars['aMenuItem'] = $foreach_aMenuItem_Sav;
}
?>
			<div class="clr"></div>
		</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ($_smarty_tpl->tpl_vars['sTplName']->value, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<hr class="hidden" />
<!-- footer -->
<div id="prefooter"></div>
<div id="footer">
	<div>© 2015 <a class="dark" href="#" target="_blank">RB&nbsp;DESIGN</a></div>
	<div id="d"></div>
</div>
<!-- //footer -->
</div>

</body>
</html><?php }
}
?>