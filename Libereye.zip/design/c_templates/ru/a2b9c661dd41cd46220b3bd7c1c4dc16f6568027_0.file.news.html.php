<?php /* Smarty version 3.1.27, created on 2015-12-21 15:30:00
         compiled from "d:\Server\domains\libereye2\Libereye\design\templates\ru\blocks\news.html" */ ?>
<?php
/*%%SmartyHeaderCode:1222556781af8d7c5f5_51529575%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a2b9c661dd41cd46220b3bd7c1c4dc16f6568027' => 
    array (
      0 => 'd:\\Server\\domains\\libereye2\\Libereye\\design\\templates\\ru\\blocks\\news.html',
      1 => 1449841681,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1222556781af8d7c5f5_51529575',
  'variables' => 
  array (
    'aNews' => 0,
    'aItem' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56781af8e1bce3_79520486',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56781af8e1bce3_79520486')) {
function content_56781af8e1bce3_79520486 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1222556781af8d7c5f5_51529575';
$_from = $_smarty_tpl->tpl_vars['aNews']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['aItem'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['aItem']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['aItem']->value) {
$_smarty_tpl->tpl_vars['aItem']->_loop = true;
$foreach_aItem_Sav = $_smarty_tpl->tpl_vars['aItem'];
?>
    <div class="col-sm-3 col-md-3 col-lg-4 news-item">
        <div class="news-title">
            <a href="#">
                <?php if ($_smarty_tpl->tpl_vars['aItem']->value['image']) {?><span class="img"><img src="/images/news/<?php echo $_smarty_tpl->tpl_vars['aItem']->value['image'];?>
" /></span><?php }?>
                <span><?php echo $_smarty_tpl->tpl_vars['aItem']->value['title'];?>
</span>
            </a>
            <div><?php echo $_smarty_tpl->tpl_vars['aItem']->value['annotation'];?>
</div>
        </div>
    </div>
<?php
$_smarty_tpl->tpl_vars['aItem'] = $foreach_aItem_Sav;
}

}
}
?>