<?php /* Smarty version 3.1.27, created on 2015-12-23 15:03:12
         compiled from "d:\Server\domains\libereye2\Libereye\design\templates\ru\visitor\template.html" */ ?>
<?php
/*%%SmartyHeaderCode:31002567ab7b01968b8_89884987%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '52453b7f667ad8b1e36716d5c3e0bfc3ef8f1487' => 
    array (
      0 => 'd:\\Server\\domains\\libereye2\\Libereye\\design\\templates\\ru\\visitor\\template.html',
      1 => 1450882991,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31002567ab7b01968b8_89884987',
  'variables' => 
  array (
    'aPage' => 0,
    'sTitle' => 0,
    'aLanguage' => 0,
    'aPhrases' => 0,
    'sTplName' => 0,
    'aLanguages' => 0,
    'aItem' => 0,
    'REQUEST_URI' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_567ab7b0374334_65278298',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_567ab7b0374334_65278298')) {
function content_567ab7b0374334_65278298 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '31002567ab7b01968b8_89884987';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php if ($_smarty_tpl->tpl_vars['aPage']->value['meta_title']) {?><title><?php echo $_smarty_tpl->tpl_vars['aPage']->value['meta_title'];?>
</title><?php } else { ?><title><?php echo $_smarty_tpl->tpl_vars['sTitle']->value;?>
</title> <?php }?>
    <?php if ($_smarty_tpl->tpl_vars['aPage']->value['meta_keys']) {?><meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['aPage']->value['meta_keys'];?>
" /> <?php }?>
    <?php if ($_smarty_tpl->tpl_vars['aPage']->value['meta_desc']) {?><meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['aPage']->value['meta_desc'];?>
" /> <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['aPage']->value['uri'] == 'main') {?>
    <link rel="stylesheet" href='/design/css/main.css' type='text/css'/>
    <?php } else { ?>
    <link rel="stylesheet" href='/design/css/pages.css' type='text/css'/>
    <?php }?>
    <link rel="stylesheet" href='/design/css/clock.css' type='text/css'/>

    <?php echo '<script'; ?>
 src="/design/js/vendor/jquery.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="/design/js/vendor/jquery.cycle.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="/design/js/vendor/jquery.mousewheel.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="/design/js/vendor/jquery.peity.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="/design/js/vendor/jquery.jscrollpane.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="/design/js/main.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="/design/js/moment.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="/design/js/moment-timezone-with-data.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="/design/js/common.js"><?php echo '</script'; ?>
>

</head>
<body>
<div class="header-gap"></div>

<?php if ($_smarty_tpl->tpl_vars['aPage']->value['uri'] == 'main') {?>
    <div class="container container-no-padding" id="slider-container">
        <div id='pager' class="hidden-sm">
            <div id='pages'></div>
        </div>
        <div class="slides" id="slides-container">
            <div class="slide" style="background-image: url('/design/pic/slider_gap.jpg');">
                <div class="row slide-info">
                    <div class="col-sm-3 col-md-5 col-lg-7">
                        <div class="info-title">Galeries Lafayette</div>
                        <div class="info-text">
                            Пространстве магазинов "Galeries Lafayettе" представлена исчерпывающая гамма коллекций предметов роскоши, - от часов и ювелирных украшений, одежды, обуви и аксессуаров класса Люкс (для женщин, мужчин,

                            подростков и детей), - до завораживающих своей красотой и качеством предметов для дома от известных мировых Домов моды и дизайна. Такое богатство и
                            «Galeries Lafayettе». Среди «Больших магазинов» "Galeries Lafayettе" исторически
                            занимает лидирующие позиции. Его репутация неприкосновенна, а прошлое «за
                            давностью лет» окутано флером таинственных историй и ярких событий,
                            запоминающих и волнующих воображение. О них Вы узнаете позже.

                            Для представителей мировых элит "Galeries Lafayettе" был единственным

                            магазином в Париже, обязательным для посещения. За ним тянутся

                            многочисленные легенды и истории, подобные шлейфу дорогих духов, который

                            никогда не исчезает окончательно, а лишь приобретает различные оттенки и

                            звучания, превращаясь из сандалового дерева то в розу, то в фиалку, меняя свой

                            характер в зависимости от времени суток и обстоятельств, но, между тем,

                            оставляет за собой право на решающий аккорд.
                        </div>
                    </div>
                    <div class="col-sm-3 col-md-5 col-md-7 links">
                        <a href="#" class="btn btn-green">Заказать митинг</a>
                        <a href="#" class="btn btn-white">Заказать видео</a>
                    </div>
                </div>
            </div>
            <div class="slide" style="background-image: url('/design/pic/slider_gap_2.jpg');">
                <div class="row slide-info">
                    <div class="col-sm-3 col-md-5 col-lg-7">
                        <div class="info-title">Galeries Lafayette</div>
                        <div class="info-text">
                            Пространстве магазинов "Galeries Lafayettе" представлена исчерпывающая гамма коллекций предметов роскоши, - от часов и ювелирных украшений, одежды, обуви и аксессуаров класса Люкс (для женщин, мужчин,

                            подростков и детей), - до завораживающих своей красотой и качеством предметов для дома от известных мировых Домов моды и дизайна. Такое богатство и
                            «Galeries Lafayettе». Среди «Больших магазинов» "Galeries Lafayettе" исторически
                            занимает лидирующие позиции. Его репутация неприкосновенна, а прошлое «за
                            давностью лет» окутано флером таинственных историй и ярких событий,
                            запоминающих и волнующих воображение. О них Вы узнаете позже.

                            Для представителей мировых элит "Galeries Lafayettе" был единственным

                            магазином в Париже, обязательным для посещения. За ним тянутся

                            многочисленные легенды и истории, подобные шлейфу дорогих духов, который

                            никогда не исчезает окончательно, а лишь приобретает различные оттенки и

                            звучания, превращаясь из сандалового дерева то в розу, то в фиалку, меняя свой

                            характер в зависимости от времени суток и обстоятельств, но, между тем,

                            оставляет за собой право на решающий аккорд.
                        </div>
                    </div>
                    <div class="col-sm-3 col-md-5 col-md-7 links">
                        <a href="#" class="btn btn-green">Заказать митинг</a>
                        <a href="#" class="btn btn-white">Заказать видео</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="slider-gradient-overlay"></div>
    </div>
    <div class="container header">
    <div class="row">
        <div class="col-sm-1 col-md-1 col-lg-2 logo">
            <a href="/"><img src="/design/pic/logo.png" /></a>
        </div>
        <div class="hidden-sm col-md-3 col-lg-3 text-right main-menu">
            <a href="/<?php echo $_smarty_tpl->tpl_vars['aLanguage']->value['alias'];?>
/page/shops/"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Shops'];?>
</a>
            <a href="/<?php echo $_smarty_tpl->tpl_vars['aLanguage']->value['alias'];?>
/page/how/"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['How it works'];?>
</a>
        </div>
        <div class="col-sm-2 col-md-1 col-lg-2"></div>
        <div class="hidden-sm col-md-2 col-lg-2">
            <span class="clock"><span class="city"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['London'];?>
</span></span>&nbsp;&nbsp;<span class="clock"><span class="city"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Paris'];?>
</span></span>
            <!--<img src="/design/pic/clock-gap-1.png" />&nbsp;&nbsp;<img src="/design/pic/clock-gap-2.png" />-->
        </div>
        <div class="col-sm-3 col-md-2 col-lg-3 personal-links text-right">
            <a href="/<?php echo $_smarty_tpl->tpl_vars['aLanguage']->value['alias'];?>
/register/"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Register'];?>
</a>&nbsp;
            <span class="sep"></span>&nbsp;
            <a href="/<?php echo $_smarty_tpl->tpl_vars['aLanguage']->value['alias'];?>
/login/"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Login'];?>
</a>
            <div class="visible-sm">
                <a href="#" class="menu-activator"><img src="/design/pic/small-menu-icon.png" /></a>
                <a href="#" class="close-menu"><img src="/design/pic/menu-close-icon.png" /></a>
            </div>
        </div>
    </div>
</div>
<?php } else { ?>
    <div class="container header">
    <div class="row">
        <div class="col-sm-1 col-md-1 col-lg-2 logo">
            <a href="/"><img src="/design/pic/logo_black.png" /></a>
        </div>
        <div class="hidden-sm col-md-3 col-lg-3 text-right main-menu">
            <a href="#">Магазины</a>
            <a href="#">Как это работает</a>
        </div>
        <div class="col-sm-2 col-md-1 col-lg-2"></div>
        <div class="hidden-sm col-md-2 col-lg-2"><img src="/design/pic/clock-gap-1_black.png" />&nbsp;&nbsp;<img src="/design/pic/clock-gap-2_black.png" /></div>
        <div class="col-sm-3 col-md-2 col-lg-3 personal-links text-right">
            <a href="#">Регистрация</a>&nbsp;
            <span class="sep"></span>&nbsp;
            <a href="#">Вход</a>
            <div class="visible-sm">
                <a href="#" class="menu-activator"><img src="/design/pic/small-menu-icon_black.png" /></a>
                <a href="#" class="close-menu">
                    <img class="hover" src="/design/pic/menu-close-icon.png" />
                    <img src="/design/pic/menu-close-icon_black.png" />
                </a>
            </div>
        </div>
    </div>
</div>
<?php }?>

<?php echo $_smarty_tpl->getSubTemplate ($_smarty_tpl->tpl_vars['sTplName']->value, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<div class="container footer">
    <div class="row">
        <div class="col-sm-6 col-md-3 col-lg-4">
            <div class="footer-logo"><a href="#"><img src="/design/pic/logo.png" /></a></div>
            <div><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Copyright'];?>
</div>
        </div>
        <div class="col-sm-3 col-md-3 col-lg-4">
            <div class="section-title"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Information'];?>
</div>
            <ul>
                <li><a href="/<?php echo $_smarty_tpl->tpl_vars['aLanguage']->value['alias'];?>
/page/how/"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['How it works'];?>
</a></li>
                <li><a href="/<?php echo $_smarty_tpl->tpl_vars['aLanguage']->value['alias'];?>
/page/faq/"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['FAQ'];?>
</a></li>
                <li><a href="/<?php echo $_smarty_tpl->tpl_vars['aLanguage']->value['alias'];?>
/page/terms/"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Terms of use'];?>
</a></li>
                <li><a href="/<?php echo $_smarty_tpl->tpl_vars['aLanguage']->value['alias'];?>
/page/contacts/"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Contacts'];?>
</a></li>
                <li><a href="/<?php echo $_smarty_tpl->tpl_vars['aLanguage']->value['alias'];?>
/page/partners/"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Partners'];?>
</a><li>
                <li>
                <?php
$_from = $_smarty_tpl->tpl_vars['aLanguages']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['aItem'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['aItem']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['aItem']->value) {
$_smarty_tpl->tpl_vars['aItem']->_loop = true;
$foreach_aItem_Sav = $_smarty_tpl->tpl_vars['aItem'];
?>
                <a href="/<?php echo $_smarty_tpl->tpl_vars['aItem']->value['alias'];
echo $_smarty_tpl->tpl_vars['REQUEST_URI']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['aItem']->value['alias'] == $_smarty_tpl->tpl_vars['aLanguage']->value['alias']) {?>style="font-size: 18px;"<?php }?> class="user-zone-link sign-in-link"><span><?php echo $_smarty_tpl->tpl_vars['aItem']->value['title'];?>
</span></a><br>
                <?php
$_smarty_tpl->tpl_vars['aItem'] = $foreach_aItem_Sav;
}
?><li>
            </ul>
        </div>
        <div class="col-sm-3 col-md-3 col-lg-4">
            <div class="section-title"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Social networks'];?>
</div>
            <ul>
                <li><a href="https://www.facebook.com/libereyeinc"><img src="/design/pic/sn_icon_fb.png" />&nbsp;Facebook</a></li>
                <li><a href="https://twitter.com/LiberEye"><img src="/design/pic/sn_icon_tw.png" />&nbsp;Twitter</a></li>
                <li><a href="https://plus.google.com/u/2/107563083501217320391/about"><img src="/design/pic/sn_icon_gp.png" />&nbsp;Google+</a></li>
                <li><a href="https://instagram.com/libereye_inc/"><img src="/design/pic/sn_icon_inst.png" />&nbsp;Instagram</a></li>
                <li><a href="http://vk.com/libereyeinc"><img src="/design/pic/sn_icon_vk.png" />&nbsp;Vkontakte</a></li>
                <li><a href="https://www.linkedin.com/company/libereye"><img src="/design/pic/sn_icon_lin.png" />&nbsp;LinkedIn</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="container footer-bottom">
    <div class="row">
        <div class="col-sm-3 col-md-4 col-lg-6 copyright">
            <?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['All Rights Reserved'];?>

        </div>
        <div class="col-sm-3 col-md-5 col-lg-6 text-right">
            <a href="/admin/"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Service entrance'];?>
</a>
        </div>
    </div>
</div>
</body>
</html><?php }
}
?>