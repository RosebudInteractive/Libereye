<?php /* Smarty version 3.1.27, created on 2015-12-22 11:33:27
         compiled from "d:\Server\domains\libereye2\Libereye\design\templates\ru\admin\shops\list.html" */ ?>
<?php
/*%%SmartyHeaderCode:282156790ad7725040_21617158%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8f602ac24430b6e93fbea7f0b8e1d2d09cbf08ca' => 
    array (
      0 => 'd:\\Server\\domains\\libereye2\\Libereye\\design\\templates\\ru\\admin\\shops\\list.html',
      1 => 1450773145,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '282156790ad7725040_21617158',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56790ad77d39f8_44069292',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56790ad77d39f8_44069292')) {
function content_56790ad77d39f8_44069292 ($_smarty_tpl) {
if (!is_callable('smarty_function_url')) require_once 'D:\\Server\\domains\\libereye2\\Libereye\\include\\classes\\utils\\smarty\\plugins\\function.url.php';

$_smarty_tpl->properties['nocache_hash'] = '282156790ad7725040_21617158';
?>
<?php echo '<script'; ?>
 language='JavaScript' src='design/templates/ru/admin/shops/shops.js'><?php echo '</script'; ?>
>

<form name="list" action="<?php echo smarty_function_url(array('link'=>'admin.shops.list'),$_smarty_tpl);?>
" method="POST">
		<input type="hidden" value="" name="act">
		<input type="hidden" value="0" name="id">
</form>		

<div id="main">
	<div id="left" style="width:0;">
	</div>
	<div id="middle2" style="margin-left: 0px;">
	<a href="<?php echo smarty_function_url(array('link'=>'admin.shops.shop_edit'),$_smarty_tpl);?>
">Добавить магазин</a><br><br>
	<?php echo $_smarty_tpl->getSubTemplate ("blocks/errors.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

        <div id="shops"></div>
        <div id="paging_here"></div>
	</div>
</div>
<?php }
}
?>