<?php /* Smarty version 3.1.27, created on 2015-12-21 18:23:48
         compiled from "d:\Server\domains\libereye2\Libereye\design\templates\ru\admin\accounts\list.html" */ ?>
<?php
/*%%SmartyHeaderCode:546556781984bb7415_49057376%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aaf7fa7ba71193dbb2313908513f48b743ba6be0' => 
    array (
      0 => 'd:\\Server\\domains\\libereye2\\Libereye\\design\\templates\\ru\\admin\\accounts\\list.html',
      1 => 1439708861,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '546556781984bb7415_49057376',
  'variables' => 
  array (
    'aLoginUserDataJson' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56781984c8f475_08210203',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56781984c8f475_08210203')) {
function content_56781984c8f475_08210203 ($_smarty_tpl) {
if (!is_callable('smarty_function_url')) require_once 'D:\\Server\\domains\\libereye2\\Libereye\\include\\classes\\utils\\smarty\\plugins\\function.url.php';

$_smarty_tpl->properties['nocache_hash'] = '546556781984bb7415_49057376';
?>
<link rel="stylesheet" href="design/js/extjs/resources/css/ext-all-gray.css" /> 
<?php echo '<script'; ?>
 type="text/javascript" src="design/js/extjs/bootstrap.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="design/js/extjs/locale/ext-lang-ru.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>var aLoginUserData = <?php echo $_smarty_tpl->tpl_vars['aLoginUserDataJson']->value;?>
;<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 language='JavaScript' src='design/templates/ru/admin/accounts/accounts.js'><?php echo '</script'; ?>
>

<form name="list" action="<?php echo smarty_function_url(array('link'=>'admin.accounts.list'),$_smarty_tpl);?>
" method="POST">
		<input type="hidden" value="" name="act">
		<input type="hidden" value="0" name="id">
</form>		

<div id="main">
	<div id="left" style="width:0;">
	</div>
	<div id="middle2" style="margin-left: 0px;">
	<a href="<?php echo smarty_function_url(array('link'=>'admin.accounts.account_edit'),$_smarty_tpl);?>
">Добавить пользователя</a><br><br>
	<?php echo $_smarty_tpl->getSubTemplate ("blocks/errors.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

			<div id="accounts" style="height:100%"></div>
	</div>
</div>
<?php }
}
?>