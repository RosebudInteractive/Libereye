<?php /* Smarty version 3.1.27, created on 2015-12-21 15:33:07
         compiled from "d:\Server\domains\libereye2\Libereye\design\templates\ru\visitor\public\login.html" */ ?>
<?php
/*%%SmartyHeaderCode:2135056781bb3324e92_12692106%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9979db9062a5d0c03772d08ffec8fd9d6d5dce5d' => 
    array (
      0 => 'd:\\Server\\domains\\libereye2\\Libereye\\design\\templates\\ru\\visitor\\public\\login.html',
      1 => 1441983811,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2135056781bb3324e92_12692106',
  'variables' => 
  array (
    'aPhrases' => 0,
    'aErrors' => 0,
    'sError' => 0,
    'sLogin' => 0,
    'aLanguage' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56781bb34253a3_08612927',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56781bb34253a3_08612927')) {
function content_56781bb34253a3_08612927 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '2135056781bb3324e92_12692106';
?>
<!--<aside class="aside-col">
<div class="widget ad">
	<div class="banner aside big">
	</div>
</div>
</aside>-->
			
<div class="main-col">

				
				<div class="profile-container">
				<header class="profile-header">
				<h1 class="profile-name"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Enter the site'];?>
</h1>
					</header>
					<form enctype="multipart/form-data" action="" method="POST" class="profile-header">
					
	
		<input type="hidden" name="act" value="login" />
		<div class="profile-data">	
			<?php if ($_smarty_tpl->tpl_vars['aErrors']->value) {?><style>.profile-header .errorlist:after{border-width:0;}</style><span class="info"><ul class="errorlist"><?php
$_from = $_smarty_tpl->tpl_vars['aErrors']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['sError'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['sError']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['sError']->value) {
$_smarty_tpl->tpl_vars['sError']->_loop = true;
$foreach_sError_Sav = $_smarty_tpl->tpl_vars['sError'];
?><li><?php echo $_smarty_tpl->tpl_vars['sError']->value;?>
</li><?php
$_smarty_tpl->tpl_vars['sError'] = $foreach_sError_Sav;
}
?></ul></span><?php }?>
			
			<div>
				<label for="id_email"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Email'];?>
<span class="required">*</span></label>
				<span class="offset"><input id="id_email" maxlength="75" name="email"  type="text" value="<?php echo $_smarty_tpl->tpl_vars['sLogin']->value;?>
">
					<span class="info"></span>
				</span>
			</div>
			<div>
				<label for="id_pass"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Password'];?>
<span class="required">*</span></label>
				<span class="offset"><input id="id_pass" maxlength="20" name="pass" type="password">
					<span class="info"></span>
				</span>
			</div>
		</div>
		<footer style="width: 550px;">
			<input type="submit" value="<?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Login'];?>
" class="button big">
			<a href="/<?php echo $_smarty_tpl->tpl_vars['aLanguage']->value['alias'];?>
/account/remind/"><span><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['Forgot your password'];?>
</span></a>

		
		
		</footer>

	
</form>

					
				</div>
				
			</div>
			<br>
<?php }
}
?>