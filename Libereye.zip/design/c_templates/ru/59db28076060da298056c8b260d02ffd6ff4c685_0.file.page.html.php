<?php /* Smarty version 3.1.27, created on 2015-12-21 15:29:41
         compiled from "d:\Server\domains\libereye2\Libereye\design\templates\ru\visitor\public\page.html" */ ?>
<?php
/*%%SmartyHeaderCode:1040856781ae56b26b3_86280290%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '59db28076060da298056c8b260d02ffd6ff4c685' => 
    array (
      0 => 'd:\\Server\\domains\\libereye2\\Libereye\\design\\templates\\ru\\visitor\\public\\page.html',
      1 => 1449844249,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1040856781ae56b26b3_86280290',
  'variables' => 
  array (
    'aPhrases' => 0,
    'aNews' => 0,
    'aItem' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56781ae5761105_89462633',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56781ae5761105_89462633')) {
function content_56781ae5761105_89462633 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1040856781ae56b26b3_86280290';
?>
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-9 col-lg-12 text-center">
            <h1><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['News'];?>
</h1>
        </div>
    </div>
    <div class="news-list row">
        <?php
$_from = $_smarty_tpl->tpl_vars['aNews']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['aItem'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['aItem']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['aItem']->value) {
$_smarty_tpl->tpl_vars['aItem']->_loop = true;
$foreach_aItem_Sav = $_smarty_tpl->tpl_vars['aItem'];
?>
        <div class="col-sm-3 col-md-3 col-lg-4 news-item    ">
            <div class="news-title">
                <a href="#">
                    <?php if ($_smarty_tpl->tpl_vars['aItem']->value['image']) {?><span class="img"><img src="/images/news/<?php echo $_smarty_tpl->tpl_vars['aItem']->value['image'];?>
" /></span><?php }?>
                    <span><?php echo $_smarty_tpl->tpl_vars['aItem']->value['title'];?>
</span>
                </a>
                <div><?php echo $_smarty_tpl->tpl_vars['aItem']->value['annotation'];?>
</div>
            </div>
        </div>
        <?php
$_smarty_tpl->tpl_vars['aItem'] = $foreach_aItem_Sav;
}
?>
    </div>
    <div class="row">
        <div class="col-sm-6 col-md-9 col-lg-12 text-center">
            <a href="#more" class="more-news"><?php echo $_smarty_tpl->tpl_vars['aPhrases']->value['More articles'];?>
</a>
        </div>
    </div>
</div><?php }
}
?>