<?php /* Smarty version 3.1.27, created on 2015-12-21 18:20:47
         compiled from "d:\Server\domains\libereye2\Libereye\design\templates\ru\blocks\errors.html" */ ?>
<?php
/*%%SmartyHeaderCode:5189567818cfac2b90_25613716%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '83a9076af6d92661f405d4d373da07593b9b5386' => 
    array (
      0 => 'd:\\Server\\domains\\libereye2\\Libereye\\design\\templates\\ru\\blocks\\errors.html',
      1 => 1439708861,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5189567818cfac2b90_25613716',
  'variables' => 
  array (
    'sJsDiv' => 0,
    'aErrors' => 0,
    'aSessErr' => 0,
    'sError' => 0,
    'bNoMessage' => 0,
    'bSessErr' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_567818cfbc3de0_16551995',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_567818cfbc3de0_16551995')) {
function content_567818cfbc3de0_16551995 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '5189567818cfac2b90_25613716';
?>
<div id="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['sJsDiv']->value)===null||$tmp==='' ? 'jsErr' : $tmp);?>
" align="left">
<?php if ($_smarty_tpl->tpl_vars['aErrors']->value || $_smarty_tpl->tpl_vars['aSessErr']->value) {?>
<?php if ($_smarty_tpl->tpl_vars['aErrors']->value) {?><br><?php }?>
<?php
$_from = $_smarty_tpl->tpl_vars['aErrors']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['sError'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['sError']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['sError']->value) {
$_smarty_tpl->tpl_vars['sError']->_loop = true;
$foreach_sError_Sav = $_smarty_tpl->tpl_vars['sError'];
?>
<b  class="error"><?php echo $_smarty_tpl->tpl_vars['sError']->value;?>
</b><br>
<?php
$_smarty_tpl->tpl_vars['sError'] = $foreach_sError_Sav;
}
?>
<?php if (!$_smarty_tpl->tpl_vars['bNoMessage']->value) {?>
<?php
$_from = $_smarty_tpl->tpl_vars['aSessErr']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['sError'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['sError']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['sError']->value) {
$_smarty_tpl->tpl_vars['sError']->_loop = true;
$foreach_sError_Sav = $_smarty_tpl->tpl_vars['sError'];
?>
<b style="color:<?php if ($_smarty_tpl->tpl_vars['bSessErr']->value) {?>#FFF<?php } else { ?>#0A9A41<?php }?>;"><?php echo $_smarty_tpl->tpl_vars['sError']->value;?>
</b><br>
<?php
$_smarty_tpl->tpl_vars['sError'] = $foreach_sError_Sav;
}
?>
<?php }?>
<br>

<?php }?>
</div><?php }
}
?>