<?php /* Smarty version 3.1.27, created on 2015-12-21 21:45:59
         compiled from "d:\Server\domains\libereye2\Libereye\design\templates\ru\admin\news\news_edit.html" */ ?>
<?php
/*%%SmartyHeaderCode:4610567848e7bad275_39844381%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a530bb5b54bbbea413122176c618dd96c608427a' => 
    array (
      0 => 'd:\\Server\\domains\\libereye2\\Libereye\\design\\templates\\ru\\admin\\news\\news_edit.html',
      1 => 1450723556,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4610567848e7bad275_39844381',
  'variables' => 
  array (
    'sUrl' => 0,
    'aNews' => 0,
    'sJs' => 0,
    'aLanguages' => 0,
    'nLangId' => 0,
    'sLang' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_567848e800af12_31373899',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_567848e800af12_31373899')) {
function content_567848e800af12_31373899 ($_smarty_tpl) {
if (!is_callable('smarty_function_url')) require_once 'D:\\Server\\domains\\libereye2\\Libereye\\include\\classes\\utils\\smarty\\plugins\\function.url.php';

$_smarty_tpl->properties['nocache_hash'] = '4610567848e7bad275_39844381';
?>
<form name="list" action="<?php echo $_smarty_tpl->tpl_vars['sUrl']->value;?>
" method="POST">
    <input type="hidden" value="" name="act">
    <input type="hidden" value="0" name="id">
</form>

<div id="main">
    <!-- left menu -->
    <div id="left">
        <div id="left_menu" class="left bluediv">
            <div class="top">
                <div>

                    <div>
                        <!--header-->
                    </div>
                </div>
            </div>
            <div class="header">
                <div class="wrap">
                    <div><a href="/admin/index.php/part_news" class="n"><img src="/design/pic/admin/up.gif" class="icon" alt="&#8592;" /></a><a href="<?php echo smarty_function_url(array('link'=>'admin.news.list'),$_smarty_tpl);?>
">Назад</a></div>
                </div>
            </div>
            <div class="middle">
                <div class="list_swap" id="list_swap">

                </div>
            </div>
            <div class="bottom">
                <div>
                    <div>
                        <!--footer-->
                    </div>
                </div>

            </div>
        </div>
        <div class="bluediv">
            <div class="topsm">
                <div>
                    <div>
                        <!--header-->
                    </div>
                </div>

            </div>
            <div class="middle" style="padding: 2px">
                <div class="menuitem"><img src="/design/pic/admin/floppy.gif" class="icon green big" alt="&#9632;" /><a href="#" onclick="document.content.submit(); return false;" class="green">Cохранить</a></div>
            </div>
            <div class="bottom">
                <div>
                    <div>

                        <!--footer-->
                    </div>
                </div>
            </div>
        </div>

        <div id="tip" class="tipdiv">
            <div class="top">
                <div>

                    <div>
                        <!--header-->
                    </div>
                </div>
            </div>
            <div class="header">
                <div class="wrap"><img src="/design/pic/admin/bulb.gif" alt="!" class="icon big dark" /><span class="dark"><strong>Подсказка</strong></span></div>
            </div>

            <div class="middle">
                <div class="wrap" id="tiptext">Отредактируйте и нажмите &laquo;Сохранить&raquo;</div>
            </div>
            <div class="bottom">
                <div>
                    <div>
                        <!--footer-->
                    </div>

                </div>
            </div>
        </div>

    </div>
    <hr class="hidden" />
    <!-- //left menu -->
    <!-- middle -->
    <div id="middle2">

        <?php echo $_smarty_tpl->getSubTemplate ("blocks/errors.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


        <div id="hk"><a href="<?php echo smarty_function_url(array('link'=>'admin.news'),$_smarty_tpl);?>
">Новости</a>&nbsp;&gt;&nbsp;<?php if ($_smarty_tpl->tpl_vars['aNews']->value['news_id']) {?>Редактирование новости: <?php echo $_smarty_tpl->tpl_vars['aNews']->value['title'][1];
} else { ?>Добавление новости<?php }?> <hr /></div>
        <h1 class="first"><?php if ($_smarty_tpl->tpl_vars['aNews']->value['news_id']) {?>Редактирование новости: <?php echo $_smarty_tpl->tpl_vars['aNews']->value['title'][1];
} else { ?>Добавление новости<?php }?></h1>

        <form method="POST" action="<?php echo $_smarty_tpl->tpl_vars['sUrl']->value;?>
" onsubmit="<?php echo $_smarty_tpl->tpl_vars['sJs']->value;?>
" enctype="multipart/form-data" name="content">
            <input type="hidden" name="act" value="<?php if ($_smarty_tpl->tpl_vars['aNews']->value['news_id']) {?>Сохранить<?php } else { ?>Создать<?php }?>" />

            <fieldset>

                <div id="ru_fields">

                    <?php
$_from = $_smarty_tpl->tpl_vars['aLanguages']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['sLang'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['sLang']->_loop = false;
$_smarty_tpl->tpl_vars['nLangId'] = new Smarty_Variable;
foreach ($_from as $_smarty_tpl->tpl_vars['nLangId']->value => $_smarty_tpl->tpl_vars['sLang']->value) {
$_smarty_tpl->tpl_vars['sLang']->_loop = true;
$foreach_sLang_Sav = $_smarty_tpl->tpl_vars['sLang'];
?>
                    <div>
                    <label for="title<?php echo $_smarty_tpl->tpl_vars['nLangId']->value;?>
"><span class="def">Заголовок (<?php echo $_smarty_tpl->tpl_vars['sLang']->value;?>
):</span>
                        <input type="text"  id="title<?php echo $_smarty_tpl->tpl_vars['nLangId']->value;?>
" name="aNews[title][<?php echo $_smarty_tpl->tpl_vars['nLangId']->value;?>
]" value="<?php echo $_smarty_tpl->tpl_vars['aNews']->value['title'][$_smarty_tpl->tpl_vars['nLangId']->value];?>
" />
                    </label><br />
                    </div>
                    <?php
$_smarty_tpl->tpl_vars['sLang'] = $foreach_sLang_Sav;
}
?>

                    <label for="image"><span class="def">Картинка:</span>
                        <input type="file"  id="image" name="image" style="background: none repeat scroll 0 0 rgba(0, 0, 0, 0);border: 0 none;height: auto;" />
                    </label><br />

                    <?php if ($_smarty_tpl->tpl_vars['aNews']->value['image']) {?><img title="<?php echo $_smarty_tpl->tpl_vars['aNews']->value['name_rus'];?>
" src="/images/news/<?php echo $_smarty_tpl->tpl_vars['aNews']->value['image'];?>
" style="padding:1em 0 0 10em;clear:both;max-width:300px;" ><br>

                    <input type="checkbox" name="image_delete" id="image_delete" style="width: 264px; background: none repeat scroll 0 0 rgba(0, 0, 0, 0);border: 0 none;height: auto;" />
                    <label for="image_delete" style="display:inline;background: none repeat scroll 0 0 rgba(0, 0, 0, 0);border: 0 none;height: auto;width:auto;">Удалить картинку</label><br>
                    <?php }?>

                    <div class="clr"></div>

                    <?php
$_from = $_smarty_tpl->tpl_vars['aLanguages']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['sLang'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['sLang']->_loop = false;
$_smarty_tpl->tpl_vars['nLangId'] = new Smarty_Variable;
foreach ($_from as $_smarty_tpl->tpl_vars['nLangId']->value => $_smarty_tpl->tpl_vars['sLang']->value) {
$_smarty_tpl->tpl_vars['sLang']->_loop = true;
$foreach_sLang_Sav = $_smarty_tpl->tpl_vars['sLang'];
?>
                    <label class="pad" for="text<?php echo $_smarty_tpl->tpl_vars['nLangId']->value;?>
">Аннотация (<?php echo $_smarty_tpl->tpl_vars['sLang']->value;?>
)</span><br />
                        <textarea style="height: 200px; font-family: 'Courier New', Courier, monospace; font-size: 13px; background: url(/design/pic/admin/html_textarea.png) 0 0 repeat; padding: 5px;; max-width: 99%; width: 99%"  id="text<?php echo $_smarty_tpl->tpl_vars['nLangId']->value;?>
" name="aNews[annotation][<?php echo $_smarty_tpl->tpl_vars['nLangId']->value;?>
]" class="allow_tab mceAdvanced"><?php echo $_smarty_tpl->tpl_vars['aNews']->value['annotation'][$_smarty_tpl->tpl_vars['nLangId']->value];?>
</textarea>
                    </label><br />
                    <?php
$_smarty_tpl->tpl_vars['sLang'] = $foreach_sLang_Sav;
}
?>

                    <div class="clr"></div>

                    <?php
$_from = $_smarty_tpl->tpl_vars['aLanguages']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['sLang'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['sLang']->_loop = false;
$_smarty_tpl->tpl_vars['nLangId'] = new Smarty_Variable;
foreach ($_from as $_smarty_tpl->tpl_vars['nLangId']->value => $_smarty_tpl->tpl_vars['sLang']->value) {
$_smarty_tpl->tpl_vars['sLang']->_loop = true;
$foreach_sLang_Sav = $_smarty_tpl->tpl_vars['sLang'];
?>
                    <label class="pad" for="full_news<?php echo $_smarty_tpl->tpl_vars['sLang']->value;?>
">Полный текст новости (<?php echo $_smarty_tpl->tpl_vars['sLang']->value;?>
)</span><br />
                        <textarea style="height: 400px; font-family: 'Courier New', Courier, monospace; font-size: 13px; background: url(/design/pic/admin/html_textarea.png) 0 0 repeat; padding: 5px;; max-width: 99%; width: 99%"  id="full_news<?php echo $_smarty_tpl->tpl_vars['nLangId']->value;?>
" name="aNews[full_news][<?php echo $_smarty_tpl->tpl_vars['nLangId']->value;?>
]" class="allow_tab mceAdvanced"><?php echo $_smarty_tpl->tpl_vars['aNews']->value['full_news'][$_smarty_tpl->tpl_vars['nLangId']->value];?>
</textarea>
                    </label><br />
                    <?php
$_smarty_tpl->tpl_vars['sLang'] = $foreach_sLang_Sav;
}
?>

                    <label class="pad r2">

                        <input type="submit" class="button" name="data" value="<?php if ($_smarty_tpl->tpl_vars['aNews']->value['news_id']) {?>Сохранить<?php } else { ?>Создать<?php }?>" />
                    </label><br />


            </fieldset></form>

    </div>
    <!-- //middle --><div class="clr"></div>

</div>



<?php }
}
?>